# fb_audience_uploader/urls.py
from django.contrib import admin
from django.urls import path
from uploader.views import home  # Import the home view from your uploader app

urlpatterns = [
    path('admin/', admin.site.urls),  # Admin URL
    path('', home, name='home'),  # Route for the homepage
]
