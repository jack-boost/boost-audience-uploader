# uploader/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

class AudienceUploadView(APIView):
    def post(self, request):
        # Your upload handling logic here
        return Response({"message": "Audience uploaded successfully!"}, status=status.HTTP_200_OK)
