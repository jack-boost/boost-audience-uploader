# uploader/urls.py
from django.urls import path
from .views import AudienceUploadView  # Replace with the correct view if different

urlpatterns = [
    path('upload-audience/', AudienceUploadView.as_view(), name='upload_audience'),  # Ensure this is correct
]
