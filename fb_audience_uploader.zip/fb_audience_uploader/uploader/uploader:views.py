# uploader/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import AudienceUploadSerializer
from .tasks import upload_audience_task
import os

class AudienceUploadView(APIView):
    def post(self, request):
        serializer = AudienceUploadSerializer(data=request.data)
        if serializer.is_valid():
            app_id = serializer.validated_data['app_id']
            app_secret = serializer.validated_data['app_secret']
            access_token = serializer.validated_data['access_token']
            ad_account_id = serializer.validated_data['ad_account_id']
            audience_name = serializer.validated_data['audience_name']
            csv_file = request.FILES['csv_file']

            # Save the file temporarily
            file_path = os.path.join('/tmp', csv_file.name)
            with open(file_path, 'wb+') as destination:
                for chunk in csv_file.chunks():
                    destination.write(chunk)

            # Trigger Celery task
            upload_audience_task.delay(app_id, app_secret, access_token, ad_account_id, audience_name, file_path)

            return Response({'message': 'Audience upload started'}, status=status.HTTP_202_ACCEPTED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
