# uploader/serializers.py
from rest_framework import serializers

class AudienceUploadSerializer(serializers.Serializer):
    app_id = serializers.CharField(max_length=255)
    app_secret = serializers.CharField(max_length=255)
    access_token = serializers.CharField(max_length=255)
    ad_account_id = serializers.CharField(max_length=255)
    audience_name = serializers.CharField(max_length=255)
    csv_file = serializers.FileField()
